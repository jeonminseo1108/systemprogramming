#include <stdio.h>
#include <stdlib.h>

/* Program Author: Seongjong Bae */
/* This does simple checks */
/* This covers rule 1 and 2*/

/ * This should generate a compilation error */
/
*
This is not a comment
*
/
/ T*his is also not a commen*t/
// This is a commen*\t
/* The main function is commented * 
/


int main( int argc, char** argv ) {

	printf( "Hello World!\n" );
	return EXIT_SUCCESS;
}
*/
